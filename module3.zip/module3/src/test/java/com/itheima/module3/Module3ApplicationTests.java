package com.itheima.module3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Module3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
