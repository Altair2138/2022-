		var count1 = [[0,0,0],[0,0,0],[0,0,0]];
		var count2 = [[0,0,0],[0,0,0],[0,0,0]];
		var sum1 = 0;
		var sum2 = 0;
		/* 骰子1 */
		var img1 = document.getElementById('dice1');
		var div1 = document.getElementById('tag1');
		var oElement;
		div1.addEventListener("dragenter", function(e) {
			e.preventDefault();
		}, false);
		div1.addEventListener("dragover", function(e) {
			e.preventDefault();
		}, false);
		div1.addEventListener("drop", function(e) {
			/* console.info(e.id); */
			e.preventDefault();
			var i = 0;
			var n = img1.cloneNode();
			n.id = "div100_img";
			n.style.top = 0 + 'px';
			n.style.left = 0 + 'px';
			div1.innerHTML = n.outerHTML;
			count1[0][0]=change(n);
			sum1++;
			sum2=clean1(count1[0][0],i,count2,sum2);
			if(sum1==9||sum2==9){
				score(count1,count2);
			}
			
		}, false);
		var div2 = document.getElementById('tag2');
		div2.addEventListener("dragenter", function(e) {
			e.preventDefault();
		}, false);
		div2.addEventListener("dragover", function(e) {
			e.preventDefault();
		}, false);
		div2.addEventListener("drop", function(e) {
			e.preventDefault();
			/* console.info(e.id); */
			var i = 1;
			var n = img1.cloneNode();
			n.style.top = 0 + 'px';
			n.style.left = 0 + 'px';
			n.id = "div101_img";
			div2.innerHTML = n.outerHTML;
			count1[0][1]=change(n);
			sum1++;
			sum2=clean1(count1[0][1],i,count2,sum2);
			if(sum1==9||sum2==9){
				score(count1,count2);
			}
		}, false);
		var div3 = document.getElementById('tag3');
		div3.addEventListener("dragenter", function(e) {
			e.preventDefault();
		}, false);
		div3.addEventListener("dragover", function(e) {
			e.preventDefault();
		}, false);
		div3.addEventListener("drop", function(e) {
			e.preventDefault();
			/* console.info(e.id); */
			var i = 2;
			var n = img1.cloneNode();
			n.style.top = 0 + 'px';
			n.style.left = 0 + 'px';
			n.id = "div102_img";
			div3.innerHTML = n.outerHTML;
			count1[0][2]=change(n);
			sum1++;
			sum2=clean1(count1[0][2],i,count2,sum2);
			if(sum1==9||sum2==9){
				score(count1,count2);
			}
		}, false);
		var div4 = document.getElementById('tag4');
		div4.addEventListener("dragenter", function(e) {
			e.preventDefault();
		}, false);
		div4.addEventListener("dragover", function(e) {
			e.preventDefault();
		}, false);
		div4.addEventListener("drop", function(e) {
			e.preventDefault();
			/* console.info(e.id); */
			var i =0;
			var n = img1.cloneNode();
			n.style.top = 0 + 'px';
			n.style.left = 0 + 'px';
			n.id = "div110_img";
			div4.innerHTML = n.outerHTML;
			count1[1][0]=change(n);
			sum1++;
			sum2=clean1(count1[1][0],i,count2,sum2);
			if(sum1==9||sum2==9){
				score(count1,count2);
			}
		}, false);
		var div5 = document.getElementById('tag5');
		div5.addEventListener("dragenter", function(e) {
			e.preventDefault();
		}, false);
		div5.addEventListener("dragover", function(e) {
			e.preventDefault();
		}, false);
		div5.addEventListener("drop", function(e) {
			e.preventDefault();
			var i = 1;
			var n = img1.cloneNode();
			n.style.top = 0 + 'px';
			n.style.left = 0 + 'px';
			n.id = "div111_img";
			div5.innerHTML = n.outerHTML;
			count1[1][1]=change(n);
			sum1++;
			sum2=clean1(count1[1][1],i,count2,sum2);
			if(sum1==9||sum2==9){
				score(count1,count2);
			}
		}, false);
		var div6 = document.getElementById('tag6');
		div6.addEventListener("dragenter", function(e) {
			e.preventDefault();
		}, false);
		div6.addEventListener("dragover", function(e) {
			e.preventDefault();
		}, false);
		div6.addEventListener("drop", function(e) {
			e.preventDefault();
			/* console.info(e.id); */
			var i = 2;
			var n = img1.cloneNode();
			n.style.top = 0 + 'px';
			n.style.left = 0 + 'px';
			n.id = "div112_img";
			div6.innerHTML = n.outerHTML;
			count1[1][2]=change(n);
			sum1++;
			sum2=clean1(count1[1][2],i,count2,sum2);
			if(sum1==9||sum2==9){
				score(count1,count2);
			}
		}, false);
		var div7 = document.getElementById('tag7');
		div7.addEventListener("dragenter", function(e) {
			e.preventDefault();
		}, false);
		div7.addEventListener("dragover", function(e) {
			e.preventDefault();
		}, false);
		div7.addEventListener("drop", function(e) {
			e.preventDefault();
			/* console.info(e.id); */
			var i = 0;
			var n = img1.cloneNode();
			n.style.top = 0 + 'px';
			n.style.left = 0 + 'px';
			n.id = "div120_img";
			div7.innerHTML = n.outerHTML;
			count1[2][0]=change(n);
			sum1++;
			sum2=clean1(count1[2][0],i,count2,sum2);
			if(sum1==9||sum2==9){
				score(count1,count2);
			}
		}, false);
		var div8 = document.getElementById('tag8');
		div8.addEventListener("dragenter", function(e) {
			e.preventDefault();
		}, false);
		div8.addEventListener("dragover", function(e) {
			e.preventDefault();
		}, false);
		div8.addEventListener("drop", function(e) {
			e.preventDefault();
			/* console.info(e.id); */
			var i =1
			var n = img1.cloneNode();
			n.style.top = 0 + 'px';
			n.style.left = 0 + 'px';
			n.id = "div121_img";
			div8.innerHTML = n.outerHTML;
			count1[2][1]=change(n);
			sum1++;
			sum2=clean1(count1[2][1],i,count2,sum2);
			if(sum1==9||sum2==9){
				score(count1,count2);
			}
		}, false);
		var div9 = document.getElementById('tag9');
		div9.addEventListener("dragenter", function(e) {
			e.preventDefault();
		}, false);
		div9.addEventListener("dragover", function(e) {
			e.preventDefault();
		}, false);
		div9.addEventListener("drop", function(e) {
			e.preventDefault();
			/* console.info(e.id); */
			var i = 2;
			var n = img1.cloneNode();
			n.style.top = 0 + 'px';
			n.style.left = 0 + 'px';
			n.id = "div122_img";
			div9.innerHTML = n.outerHTML;
			count1[2][2]=change(n);
			sum1++;
			sum2=clean1(count1[2][2],i,count2,sum2);
			if(sum1==9||sum2==9){
				score(count1,count2);
			}
		}, false);
		/* 骰子2 */
		var img2 = document.getElementById('dice2');
		var div10 = document.getElementById('tag10');
		var oElement;
		div10.addEventListener("dragenter", function(e) {
			e.preventDefault();
		}, false);
		div10.addEventListener("dragover", function(e) {
			e.preventDefault();
		}, false);
		div10.addEventListener("drop", function(e) {
			e.preventDefault();
			/* console.info(e.id); */
			var i=0;
			var n = img2.cloneNode();
			n.id = "div200_img";
			n.style.top = 0 + 'px';
			n.style.left = 0 + 'px';
			div10.innerHTML = n.outerHTML;
			count2[0][0]=change(n)
			sum2++;
			sum1=clean2(count2[0][0],i,count1,sum1);
			if(sum1==9||sum2==9){
				score(count1,count2);
			}
		}, false);
		var div11 = document.getElementById('tag11');
		div11.addEventListener("dragenter", function(e) {
			e.preventDefault();
		}, false);
		div11.addEventListener("dragover", function(e) {
			e.preventDefault();
		}, false);
		div11.addEventListener("drop", function(e) {
			e.preventDefault();
			/* console.info(e.id); */
			var i = 1;
			var n = img2.cloneNode();
			n.style.top = 0 + 'px';
			n.style.left = 0 + 'px';
			n.id = "div201_img";
			div11.innerHTML = n.outerHTML;
			count2[0][1]=change(n);
			sum2++;
			sum1=clean2(count2[0][1],i,count1,sum1);
			if(sum1==9||sum2==9){
				score(count1,count2);
			}
		}, false);
		var div12 = document.getElementById('tag12');
		div12.addEventListener("dragenter", function(e) {
			e.preventDefault();
		}, false);
		div12.addEventListener("dragover", function(e) {
			e.preventDefault();
		}, false);
		div12.addEventListener("drop", function(e) {
			e.preventDefault();
			/* console.info(e.id); */
			var i = 2;
			var n = img2.cloneNode();
			n.style.top = 0 + 'px';
			n.style.left = 0 + 'px';
			n.id = "div202_img";
			div12.innerHTML = n.outerHTML;
			count2[0][2]=change(n);
			sum2++;
			sum1=clean2(count2[0][2],i,count1,sum1);
			if(sum1==9||sum2==9){
				score(count1,count2);
			}
		}, false);
		var div13 = document.getElementById('tag13');
		div13.addEventListener("dragenter", function(e) {
			e.preventDefault();
		}, false);
		div13.addEventListener("dragover", function(e) {
			e.preventDefault();
		}, false);
		div13.addEventListener("drop", function(e) {
			e.preventDefault();
			/* console.info(e.id); */
			var i = 0;
			var n = img2.cloneNode();
			n.style.top = 0 + 'px';
			n.style.left = 0 + 'px';
			n.id = "div210_img";
			div13.innerHTML = n.outerHTML;
			count2[1][0]=change(n);
			sum2++;
			sum1=clean2(count2[1][0],i,count1,sum1);
			if(sum1==9||sum2==9){
				score(count1,count2);
			}
		}, false);
		var div14 = document.getElementById('tag14');
		div14.addEventListener("dragenter", function(e) {
			e.preventDefault();
		}, false);
		div14.addEventListener("dragover", function(e) {
			e.preventDefault();
		}, false);
		div14.addEventListener("drop", function(e) {
			e.preventDefault();
			/* console.info(e.id); */
			var i = 1;
			var n = img2.cloneNode();
			n.style.top = 0 + 'px';
			n.style.left = 0 + 'px';
			n.id = "div211_img";
			div14.innerHTML = n.outerHTML;
			count2[1][1]=change(n);
			sum2++;
			sum1=clean2(count2[1][1],i,count1,sum1);
			if(sum1==9||sum2==9){
				score(count1,count2);
			}
		}, false);
		var div15 = document.getElementById('tag15');
		div15.addEventListener("dragenter", function(e) {
			e.preventDefault();
		}, false);
		div15.addEventListener("dragover", function(e) {
			e.preventDefault();
		}, false);
		div15.addEventListener("drop", function(e) {
			e.preventDefault();
			/* console.info(e.id); */
			var i = 2;
			var n = img2.cloneNode();
			n.style.top = 0 + 'px';
			n.style.left = 0 + 'px';
			n.id = "div212_img";
			div15.innerHTML = n.outerHTML;
			count2[1][2]=change(n);
			sum2++;
			sum1=clean2(count2[1][2],i,count1,sum1);
			if(sum1==9||sum2==9){
				score(count1,count2);
			}
		}, false);
		var div16 = document.getElementById('tag16');
		div16.addEventListener("dragenter", function(e) {
			e.preventDefault();
		}, false);
		div16.addEventListener("dragover", function(e) {
			e.preventDefault();
		}, false);
		div16.addEventListener("drop", function(e) {
			e.preventDefault();
			/* console.info(e.id); */
			var i = 0;
			var n = img2.cloneNode();
			n.style.top = 0 + 'px';
			n.style.left = 0 + 'px';
			n.id = "div220_img";
			div16.innerHTML = n.outerHTML;
			count2[2][0] = change(n);
			sum2++;
			sum1=clean2(count2[2][0],i,count1,sum1);
			if(sum1==9||sum2==9){
				score(count1,count2);
			}
		}, false);
		var div17 = document.getElementById('tag17');
		div17.addEventListener("dragenter", function(e) {
			e.preventDefault();
		}, false);
		div17.addEventListener("dragover", function(e) {
			e.preventDefault();
		}, false);
		div17.addEventListener("drop", function(e) {
			e.preventDefault();
			/* console.info(e.id); */
			var i = 1;
			var n = img2.cloneNode();
			n.style.top = 0 + 'px';
			n.style.left = 0 + 'px';
			n.id = "div221_img";
			div17.innerHTML = n.outerHTML;
			count2[2][1]=change(n);
			sum2++;
			sum1=clean2(count2[2][1],i,count1,sum1);
			if(sum1==9||sum2==9){
				score(count1,count2);
			}
		}, false);
		var div18 = document.getElementById('tag18');
		div18.addEventListener("dragenter", function(e) {
			e.preventDefault();
		}, false);
		div18.addEventListener("dragover", function(e) {
			e.preventDefault();
		}, false);
		div18.addEventListener("drop", function(e) {
			e.preventDefault();
			/* console.info(e.id); */
			var i = 2;
			var n = img2.cloneNode();
			n.style.top = 0 + 'px';
			n.style.left = 0 + 'px';
			n.id = "div222_img";
			div18.innerHTML = n.outerHTML;
			count2[2][2]=change(n);
			sum2++;
			sum1=clean2(count2[2][2],i,count1,sum1);
			if(sum1==9||sum2==9){
				score(count1,count2);
			}
		}, false);
function change(n){
	if(n.src=="https://s2.loli.net/2022/10/12/wz6ZJl5qDtnrbIa.png"){
		return 1;
	}
	else if(n.src=="https://s2.loli.net/2022/10/12/ZYDkWtFJSzPyUHd.png"){
		return 2;
	}
	else if(n.src=="https://s2.loli.net/2022/10/12/LW85oRc7Du3Aw6g.png"){
		return 3;
	}
	else if(n.src=="https://s2.loli.net/2022/10/12/PIrLXVEbYyeN2GR.png"){
		return 4;
	}
	else if(n.src=="https://s2.loli.net/2022/10/12/mnTVSMRyz6JfugL.png"){
		return 5;
	}
	else if(n.src=="https://s2.loli.net/2022/10/12/32maIGn8hp4tD7M.png"){
		return 6;
	}
}
function clean1(tag,num,count2,sum){
	var i;
	for(i=0;i<3;i++){
		if(count2[i][num] != 0){
			if(count2[i][num]==tag){
				count2[i][num]=0;
				document.getElementById("div2"+i+num+"_img").remove();
				sum--;
			}
		}
	}
	return sum;
}
function clean2(tag,num,count1,sum){
	var i;
	for(i=0;i<3;i++){
		if(count1[i][num] != 0){
			if(count1[i][num]==tag){
				count1[i][num]=0;
				document.getElementById("div1"+i+num+"_img").remove();
				sum--;
			}
		}
	}
	return sum;
}
function score(count1,count2){
		var i=0,j=0;
		var score1=0,score2=0;
		for(j=0;j<3;j++){
			var sum = [0,0,0,0,0,0,0];
			for(i=0;i<3;i++){
				if(count1[i][j]!=0){
					sum[count1[i][j]]++;
				}
			}
			score1=get_line(sum)+score1;
		}
		for(j=0;j<3;j++){
			var sum = [0,0,0,0,0,0,0];
			for(i=0;i<3;i++){
				if(count2[i][j]!=0){
					sum[count2[i][j]]++;
				}
			}
			score2=get_line(sum)+score2;
		}
		var flag;
		if(score1>score2){
			flag="A胜利！"
		}
		else if(score1==score2){
			flag="平局！"
		}
		else{
			flag="B胜利！"
		}
		alert("A的分数为："+score1+"\n"+"B的分数为："+score2+"\n"+flag);
		window.location.href="page1.html";
}
function get_line(sum){
	var line=0;
	var i;
	for(i=1;i<7;i++){
		
		if(sum[i]!=0){
			line=i*sum[i]*sum[i]+line;
		}
	}
	return line;
}