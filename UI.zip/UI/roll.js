function rollTheDice1() {
				document.getElementById("dice1").src = "https://s2.loli.net/2022/10/12/QJpUmNLyoHxZ6RI.gif";
				setTimeout(function () {
					var randomNumber = Math.floor(Math.random() * 6) + 1;
					if(randomNumber==1){
						document.getElementById("dice1").src = "https://s2.loli.net/2022/10/12/wz6ZJl5qDtnrbIa.png";
					}
					else if(randomNumber==2){
						document.getElementById("dice1").src = "https://s2.loli.net/2022/10/12/ZYDkWtFJSzPyUHd.png";
					}
					else if(randomNumber==3){
						document.getElementById("dice1").src = "https://s2.loli.net/2022/10/12/LW85oRc7Du3Aw6g.png";
					}
					else if(randomNumber==4){
						document.getElementById("dice1").src = "https://s2.loli.net/2022/10/12/PIrLXVEbYyeN2GR.png";
					}
					else if(randomNumber==5){
						document.getElementById("dice1").src = "https://s2.loli.net/2022/10/12/mnTVSMRyz6JfugL.png";
					}
					else{
						document.getElementById("dice1").src = "https://s2.loli.net/2022/10/12/32maIGn8hp4tD7M.png";
					}
				}, 700);
				}
function rollTheDice2() {
				document.getElementById("dice2").src = "https://s2.loli.net/2022/10/12/QJpUmNLyoHxZ6RI.gif";
				setTimeout(function () {
					var randomNumber = Math.floor(Math.random() * 6) + 1;
					if(randomNumber==1){
						document.getElementById("dice2").src = "https://s2.loli.net/2022/10/12/wz6ZJl5qDtnrbIa.png";
					}
					else if(randomNumber==2){
						document.getElementById("dice2").src = "https://s2.loli.net/2022/10/12/ZYDkWtFJSzPyUHd.png";
					}
					else if(randomNumber==3){
						document.getElementById("dice2").src = "https://s2.loli.net/2022/10/12/LW85oRc7Du3Aw6g.png";
					}
					else if(randomNumber==4){
						document.getElementById("dice2").src = "https://s2.loli.net/2022/10/12/PIrLXVEbYyeN2GR.png";
					}
					else if(randomNumber==5){
						document.getElementById("dice2").src = "https://s2.loli.net/2022/10/12/mnTVSMRyz6JfugL.png";
					}
					else{
						document.getElementById("dice2").src = "https://s2.loli.net/2022/10/12/32maIGn8hp4tD7M.png";
					}
				}, 700);
				}